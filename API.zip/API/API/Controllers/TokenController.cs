﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Threading.Tasks;
using API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private readonly UserContext _context;
        private IConfiguration _config;
        public TokenController(UserContext context, IConfiguration config)
        {
            _config = config;
            _context = context;
        }

        [HttpGet]
        public string GetRandomToken()
        {
            var jwt = new JwtService(_config);
            var token = jwt.GenerateSecurityToken("fake@email.com");
            return token;
        }

    [HttpPost]
        public string PostToken(User user)
        {
            var foundUser = _context.User.Where(u => u.Username == user.Username).FirstOrDefault();

            if (foundUser == null)
            {
                return "Usuario no valido";
            }

            if (foundUser.Password == user.Password)
            {
                var jwt = new JwtService(_config);
                var token = jwt.GenerateSecurityToken(foundUser.Username);
                return token;
            }

            return "fallo";
        }
    }
}