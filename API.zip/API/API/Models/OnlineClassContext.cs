﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models
{
    public class OnlineClassContext: DbContext
    {

        public OnlineClassContext(DbContextOptions<OnlineClassContext> options)
            : base(options)
        {
        }

        public DbSet<OnlineClass> OnlineClass { get; set; }
    }
}
